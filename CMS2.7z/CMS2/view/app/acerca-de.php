<h3>
    <a href="<?php echo $_SESSION['home'] ?>" title="Inicio">Inicio</a> <span>| Acerca de</span>
</h3>
<div class="row">
    <i class="large material-icons">info_outline</i>
    <p>
        Esta página muestra partidos relacionadas con la Lec.
    </p>
    <p>
        Está desarrollada en PHP con Programación orientada a Objetos, siguiendo el patrón Modelo Vista Controlador y
        utiliza MySQL para la persistencia de datos.
    </p>
</div>
