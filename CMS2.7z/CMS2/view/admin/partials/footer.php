</section>
</main>
<footer class="center-align">
    © <?php echo date("Y") ?> Panel de Administración.
    <a href="https://jairogarciarincon.com" target="_blank" title="Ángel Arana Barco">
        Ángel Arana Barco
    </a>
</footer>


</body>

<!--JS-->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script src="<?php echo $_SESSION['public'] ?>js/admin.js"></script>

</html>
