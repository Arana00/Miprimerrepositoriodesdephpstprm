$(document).ready(function(){

    //Sidenav en móviles
    $('.sidenav').sidenav();

});